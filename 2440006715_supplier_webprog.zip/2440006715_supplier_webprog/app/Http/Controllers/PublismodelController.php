<?php

namespace App\Http\Controllers;

use App\Models\publismodel;
use App\Models\bookmodel;
use Illuminate\Http\Request;

class PublismodelController extends Controller
{
    public function Publis()
    {
        $publis_list = publismodel::all();
        return view('publis', compact('publis_list'));
    }

    public function Publis_info($id)
    {
        $book_list = bookmodel::where('publisher_id', $id)->get();
        $publis_info = publismodel::find($id);
        return view('publis_info', compact('publis_info', 'book_list'));
    }
}
