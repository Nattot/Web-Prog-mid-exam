<?php

namespace App\Http\Controllers;

use App\Models\boocategmodel;
use App\Models\categmodel;
use Illuminate\Http\Request;

class BoocategmodelController extends Controller
{
    public function Boocateg($id)
    {
        $book_list = boocategmodel::where('category_id', $id)->get();
        $boocateg = categmodel::find($id);
        return view('boocateg', compact('boocateg', 'book_list'));
    }
}
