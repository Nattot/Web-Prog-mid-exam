<?php

namespace App\Http\Controllers;

use App\Models\bookmodel;
use Illuminate\Http\Request;

class BookmodelController extends Controller
{
    public function Home()
    {
        $book_list = bookmodel::all();

        return view('home', compact('book_list'));
    }

    public function Book_info($id)
    {
        $book_info = bookmodel::find($id);
        return view('book_info', compact('book_info'));
    }
}
