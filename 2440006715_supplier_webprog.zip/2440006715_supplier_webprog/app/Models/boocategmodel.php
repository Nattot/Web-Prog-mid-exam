<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class boocategmodel extends Model
{
    public $timestamps = false;
    use HasFactory;

    public function boocategbook()
    {
        return $this->belongsTo(bookmodel::class, 'book_id');
    }

    public function categbookcateg()
    {
        return $this->belongsTo(categmodel::class);
    }
}
