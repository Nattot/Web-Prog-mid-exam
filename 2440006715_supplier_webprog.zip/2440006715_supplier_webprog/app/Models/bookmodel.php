<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class bookmodel extends Model
{
    public $timestamps = false;
    use HasFactory;

    public function bookpublis()
    {
        return $this->belongsTo(publismodel::class, 'publisher_id');
    }

    public function bookcateg()
    {
        return $this->hasMany(boocategmodel::class);
    }
}
