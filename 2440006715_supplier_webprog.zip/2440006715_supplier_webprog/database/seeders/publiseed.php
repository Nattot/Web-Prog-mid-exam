<?php

namespace Database\Seeders;

use App\Models\publismodel;
use Illuminate\Database\Seeder;

class publiseed extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        publismodel::create([
            'name' => 'Yen Press',
            'address' => '1150 W 30th Street, 19th floor, New York, New York 10001, Amerika Serikat',
            'phone' => '(800) 759-0190',
            'email' => 'yenpress@yenpress.com',
            'image' => 'Yen_Publish.png',
        ]);
        publismodel::create([
            'name' => 'Shogakukan',
            'address' => '91 Bencoolen Street #03-05 Sunshine Plaza, Singapore 189652',
            'phone' => '+65 6557-0178',
            'email' => 'info@shogakukan.asia',
            'image' => 'Shogakukan_Publish.png',
        ]);
        publismodel::create([
            'name' => 'Viz Media',
            'address' => 'PO Box 77010, San Francisco, California 94107, Amerika Serikat',
            'phone' => '(415) 546-7073',
            'email' => 'support@viz.com',
            'image' => 'Viz_Media_Publish.png',
        ]);
    }
}
