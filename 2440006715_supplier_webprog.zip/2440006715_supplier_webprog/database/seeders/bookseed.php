<?php

namespace Database\Seeders;

use App\Models\bookmodel;
use Illuminate\Database\Seeder;

class bookseed extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        bookmodel::create([
            'publisher_id' => 1,
            'title' => 'Konosuba: Gods Blessing on This Wonderful World!',
            'author' => 'Natsume Akatsuki',
            'year' => 2013,
            'synopsis' => 'Dalam perjalanan pulang, Kazuma meninggal saat mencoba menyelamatkan seorang gadis dari truk yang melaju—atau begitulah yang dia yakini. Kenyataannya, "truk" itu adalah traktor yang bergerak lambat, dan dia hanya mati karena syok.',
            'image' => 'book_1.png',
        ]);
        bookmodel::create([
            'publisher_id' => 1,
            'title' => 'Spice & Wolf',
            'author' => 'Isuna Hasekura',
            'year' => 2006,
            'synopsis' => 'Seorang pedagang muda yang bepergian, Kraft Lawrence telah terbiasa dengan hari-hari berkeliaran dan berdagang. Sampai suatu hari yang aneh di mana pedagang itu menemukan seorang gadis muda seperti serigala tertidur di gerobaknya.',
            'image' => 'book_2.png',
        ]);
        bookmodel::create([
            'publisher_id' => 2,
            'title' => 'Magic Kaito',
            'author' => 'Gosho Aoyama',
            'year' => 1987,
            'synopsis' => 'Kaito Kuroba, seorang siswa remaja normal yang ayahnya sering absen. Ketika ayahnya meninggal dalam keadaan misterius, dia dibuat sadar akan identitas rahasia ayahnya; ',
            'image' => 'book_3.png',
        ]);
        bookmodel::create([
            'publisher_id' => 3,
            'title' => 'Yona of the Dawn',
            'author' => 'Mizuho Kusanagi',
            'year' => 2009,
            'synopsis' => 'Sebagai putri tunggal Kouka, Yona menjalani kehidupan yang mewah dan nyaman. Jatuh cinta dengan sepupunya, Su-won, dan dilindungi oleh pengawalnya, Son Hak.',
            'image' => 'book_4.png',
        ]);
        bookmodel::create([
            'publisher_id' => 1,
            'title' => 'Sword Art Online',
            'author' => 'Reki Kawahara',
            'year' => 2009,
            'synopsis' => 'Pada tahun 2022, para gamer bersukacita karena Sword Art Online-sebuah VRMMORPG (Virtual Reality Massively Multiplayer Online Role Playing Game), memungkinkan pemain untuk mengambil keuntungan penuh dari teknologi game terbaik: NerveGear.',
            'image' => 'book_5.png',
        ]);
    }
}
