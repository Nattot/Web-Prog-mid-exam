<?php

namespace Database\Seeders;

use App\Models\categmodel;
use Illuminate\Database\Seeder;

class categseed extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        categmodel::create([
            'name' => 'Adventure',
        ]);
        categmodel::create([
            'name' => 'Fantasy',
        ]);
        categmodel::create([
            'name' => 'Comedy',
        ]);
        categmodel::create([
            'name' => 'Romance',
        ]);
    }
}
