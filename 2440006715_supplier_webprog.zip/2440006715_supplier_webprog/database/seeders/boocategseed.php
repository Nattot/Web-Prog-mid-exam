<?php

namespace Database\Seeders;

use App\Models\boocategmodel;
use Illuminate\Database\Seeder;

class boocategseed extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        boocategmodel::create([
            'book_id'=>1,
            'category_id'=>1,
        ]);
        boocategmodel::create([
            'book_id'=>1,
            'category_id'=>2,
        ]);
        boocategmodel::create([
            'book_id'=>1,
            'category_id'=>3,
        ]);
        boocategmodel::create([
            'book_id'=>2,
            'category_id'=>1,
        ]);
        boocategmodel::create([
            'book_id'=>2,
            'category_id'=>2,
        ]);
        boocategmodel::create([
            'book_id'=>2,
            'category_id'=>4,
        ]);
        boocategmodel::create([
            'book_id'=>3,
            'category_id'=>1,
        ]);
        boocategmodel::create([
            'book_id'=>3,
            'category_id'=>3,
        ]);
        boocategmodel::create([
            'book_id'=>3,
            'category_id'=>4,
        ]);
        boocategmodel::create([
            'book_id'=>4,
            'category_id'=>2,
        ]);
        boocategmodel::create([
            'book_id'=>4,
            'category_id'=>3,
        ]);
        boocategmodel::create([
            'book_id'=>4,
            'category_id'=>4,
        ]);
        boocategmodel::create([
            'book_id'=>5,
            'category_id'=>1,
        ]);
        boocategmodel::create([
            'book_id'=>5,
            'category_id'=>2,
        ]);
        boocategmodel::create([
            'book_id'=>5,
            'category_id'=>3,
        ]);
        boocategmodel::create([
            'book_id'=>5,
            'category_id'=>4,
        ]);
    }
}
