@extends('navbar')
@section('title', 'Publisher')
@section('body')

<body>
    <div class="d-flex justify-content-center">
        <div class="row">
            <div class="card p-4" style="width: 18rem;">
                <img src="{{asset('storage/' . $publis_info->image)}}" class="card-img-top" alt="...">
                <div class="card-body">
                    <h5 class="card-title">{{$publis_info->name}}</h5>
                    <p class="card-text">{{$publis_info->address}}</p>
                    <p class="card-text">{{$publis_info->phone}}</p>
                    <p class="card-text">{{$publis_info->email}}</p>

                </div>
            </div>
            @foreach($book_list as $book)
            <div class="card" style="width: 18rem;">
                <img src="{{asset('storage/' . $book->image)}}" class="card-img-top" alt="...">
                <div class="card-body">
                    <h5 class="card-title">{{$book->title}}</h5>
                    <p class="card-text">by: {{$book->author}}</p>
                </div>
                <div class="card-body d-flex align-items-end">
                    <a href="/book_info/{{$book->id}}" class="btn btn-primary">Detail</a>
                </div>
            </div>
            @endforeach
        </div>
    </div>
</body>

@endsection