@extends('navbar')
@section('title', 'Category')
@section('body')

<body>
    <div class="d-flex justify-content-center">
        <h1 class="text-white bg-secondary">
            {{$boocateg->name}}
        </h1>
    </div>
    <div class="d-flex justify-content-center">
        <div class="row">
            <div>

            </div>
            @foreach($book_list as $book)
            <div class="card" style="width: 18rem;">
                <img src="{{asset('storage/' . $book->boocategbook->image)}}" class="card-img-top" alt="...">
                <div class="card-body">
                    <h5 class="card-title">{{$book->boocategbook->title}}</h5>
                    <p class="card-text">by: {{$book->boocategbook->author}}</p>
                </div>
                <div class="card-body d-flex align-items-end">
                    <a href="/book_info/{{$book->boocategbook->id}}" class="btn btn-primary">Detail</a>
                </div>
            </div>
            @endforeach
        </div>
    </div>
</body>

@endsection