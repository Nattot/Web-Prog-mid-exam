@extends('navbar')
@section('title', 'Home')
@section('body')

<body>
    <div class="d-flex justify-content-center">
        <div class="row">
            @foreach($book_list as $book)
            <div class="card" style="width: 18rem;">
                <img src="{{asset('storage/' . $book->image)}}" class="card-img-top" alt="...">
                <div class="card-body">
                    <h5 class="card-title">{{$book->title}}</h5>
                    <p class="card-text">by: {{$book->author}}</p>
                </div>
                <div class="card-body d-flex align-items-end">
                    <a href="/book_info/{{$book->id}}" class="btn btn-primary">Detail</a>
                </div>
            </div>
            @endforeach
        </div>
    </div>
</body>

@endsection