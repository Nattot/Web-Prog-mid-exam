@extends('navbar')
@section('title', 'Book')
@section('body')

<body>
    <div class="d-flex justify-content-center">
        <div class="row">
            <div class="card" style="width: 18rem;">
                <img src="{{asset('storage/' . $book_info->image)}}" class="card-img-top" alt="...">
                <div class="card-body">
                    <h5 class="card-title">Title: {{$book_info->title}}</h5>
                    <p class="card-text">Author: {{$book_info->author}}</p>
                    <p class="card-text">Publisher: {{$book_info->bookpublis->name}}</p>
                    <p class="card-text">Year: {{$book_info->year}}</p>
                    <p class="card-text"><br>{{$book_info->synopsis}}</p>
                </div>
            </div>
        </div>
    </div>
</body>

@endsection