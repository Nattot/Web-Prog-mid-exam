<!DOCTYPE html>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM" crossorigin="anonymous"></script>

<title>
    <?php echo $__env->yieldContent('title'); ?>
</title>

<head>
    <div style="height: 30px; background-color: rgba(255, 193, 7);">
    </div>
    <div style="height: 40px; background-color: rgba(255, 193, 7);">
        <h1 class="text-center text-white">
            Giant Book Supplier
        </h1>
    </div>
    <div style="height: 40px; background-color: rgba(255, 193, 7);">
    </div>

    <div class="d-flex justify-content-center">
        <nav class="navbar navbar-expand-lg navbar-light">
            <div class="container-fluid">
                <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNavDropdown" aria-controls="navbarNavDropdown" aria-expanded="false" aria-label="Toggle navigation">
                    <span class="navbar-toggler-icon"></span>
                </button>
                <div class="collapse navbar-collapse" id="navbarNavDropdown">
                    <ul class="navbar-nav">
                        <li class="nav-item">
                            <a class="nav-link text-primary" aria-current="page" href="/">Home</a>
                        </li>
                        <li class="nav-item dropdown">
                            <a class="nav-link dropdown-toggle text-primary" href="#" id="navbarDropdownMenuLink" role="button" data-bs-toggle="dropdown" aria-expanded="false">
                                Category
                            </a>
                            <ul class="dropdown-menu" aria-labelledby="navbarDropdownMenuLink">
                                <?php $__currentLoopData = $category_list; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $categbar): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <a class="dropdown-item text-primary" href="/boocateg/<?php echo e($categbar->id); ?>"><?php echo e($categbar->name); ?></a>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </ul>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link text-primary" href="/publis">Publisher</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link text-primary" href="/contact">Contact</a>
                        </li>
                    </ul>
                </div>
            </div>
        </nav>
    </div>
</head>

<?php echo $__env->yieldContent('body'); ?>

<div class="pe-3 bg-primary">
    <h2 class="text-center text-white">
        Daniel Alexander-2440006715-LI01-WebProg
    </h2>
    <h4 class="text-center text-white">
        © Happy Book Store 2022
    </h4>
</div><?php /**PATH D:\SUNIB\B I N U S\sem 5\web prog\uts webprog\2440006715_supplier_webprog\resources\views/navbar.blade.php ENDPATH**/ ?>