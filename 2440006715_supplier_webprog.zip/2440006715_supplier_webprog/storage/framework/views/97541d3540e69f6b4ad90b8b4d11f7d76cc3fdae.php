
<?php $__env->startSection('title', 'Book'); ?>
<?php $__env->startSection('body'); ?>

<body>
    <div class="d-flex justify-content-center">
        <div class="row">
            <div class="card" style="width: 18rem;">
                <img src="<?php echo e(asset('storage/' . $book_info->image)); ?>" class="card-img-top" alt="...">
                <div class="card-body">
                    <h5 class="card-title">Title: <?php echo e($book_info->title); ?></h5>
                    <p class="card-text">Author: <?php echo e($book_info->author); ?></p>
                    <p class="card-text">Publisher: <?php echo e($book_info->bookpublis->name); ?></p>
                    <p class="card-text">Year: <?php echo e($book_info->year); ?></p>
                    <p class="card-text"><br><?php echo e($book_info->synopsis); ?></p>
                </div>
            </div>
        </div>
    </div>
</body>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\SUNIB\B I N U S\sem 5\web prog\uts webprog\2440006715_supplier_webprog\resources\views/book_info.blade.php ENDPATH**/ ?>