<?php $__env->startSection('title', 'Home'); ?>
<?php $__env->startSection('body'); ?>

<body>
    <div class="d-flex justify-content-center">
        <div class="row">
            <?php $__currentLoopData = $book_list; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $book): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="card" style="width: 18rem;">
                <img src="<?php echo e(asset('storage/' . $book->image)); ?>" class="card-img-top" alt="...">
                <div class="card-body">
                    <h5 class="card-title"><?php echo e($book->title); ?></h5>
                    <p class="card-text">by: <?php echo e($book->author); ?></p>
                </div>
                <div class="card-body d-flex align-items-end">
                    <a href="/book_info/<?php echo e($book->id); ?>" class="btn btn-primary">Detail</a>
                </div>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>
</body>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\SUNIB\B I N U S\sem 5\web prog\uts webprog\2440006715_supplier_webprog\resources\views/home.blade.php ENDPATH**/ ?>