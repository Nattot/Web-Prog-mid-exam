
<?php $__env->startSection('title', 'Contact Us'); ?>
<?php $__env->startSection('body'); ?>

<body>
    <div class="d-flex justify-content-center">
        <div class="row">
            <h1 class="text-white bg-secondary">
                Contact
            </h1>
            <h2 class="text-black">
                Store address :
            </h2>
            <p class="text-black">
                Jalan Pembangungan Baru Raya, <br>
                Kompleks Pertokoan Emerald Blok III/12 <br>
                Bintaro, Tangerang Selatan <br>
                Indonesia
            </p>
            <h2 class="text-black">
                Open Daily :
            </h2>
            <p class="text-black">
                08:00 - 20:00
            </p>
            <h2 class="text-black">
                Contact :
            </h2>
            <p class="text-black">
                Phone : 021-08899776655 <br>
                Email : happybookstore@happy.com
            </p>
        </div>
    </div>
</body>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\SUNIB\B I N U S\sem 5\web prog\uts webprog\2440006715_supplier_webprog\resources\views/contact.blade.php ENDPATH**/ ?>