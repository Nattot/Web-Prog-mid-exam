<?php

use App\Http\Controllers\BoocategmodelController;
use App\Http\Controllers\BookmodelController;
use App\Http\Controllers\PublismodelController;
use App\Models\categmodel;
use Illuminate\Support\Facades\View;
use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', [BookmodelController::class, 'Home']);

Route::get('/boocateg/{id}', [BoocategmodelController::class, 'Boocateg']);

Route::get('/book_info/{id}', [BookmodelController::class, 'Book_info']);

Route::get('/publis', [PublismodelController::class, 'Publis']);

Route::get('/publis_info/{id}', [PublismodelController::class, 'Publis_info']);

Route::get('/contact', function()
{
    return view('contact');
});

View::composer('navbar', function($categbar)
{
    $category_list = categmodel::get();
    $categbar->with(['category_list'=>$category_list]);
});